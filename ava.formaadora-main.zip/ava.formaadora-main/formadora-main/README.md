# Consulta Cep

Projeto simples criado em Angular v 14.2.8.

## Você pode acessar o site do projeto Consulta Cep

https://consulta-cep-via-cep.vercel.app/

## Layout App



## Tecnologias utilizadas

Angular versão 14.2.8

## API externa

https://viacep.com.br/



